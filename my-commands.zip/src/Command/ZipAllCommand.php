<?php
namespace MyCommands\Command;

use Symfony\Component\Console\Command\Command;
use Symfony\Component\Console\Input\InputInterface;
use Symfony\Component\Console\Output\OutputInterface;
use Symfony\Component\Console\Style\SymfonyStyle;
use Symfony\Component\Console\Attribute\AsCommand;
use ZipArchive;

#[AsCommand(name: 'zip:all', description: 'Compresses all files in the current directory where the command is executed')]
class ZipAllCommand extends Command
{
    protected function execute(InputInterface $input, OutputInterface $output): int
    {
        $io = new SymfonyStyle($input, $output);
        $cwd = getcwd();
        $targetDir = $cwd;

        $zipPath = $cwd . DIRECTORY_SEPARATOR . basename($cwd) . '.zip';
        $zip = new ZipArchive();
        if ($zip->open($zipPath, ZipArchive::CREATE | ZipArchive::OVERWRITE) !== true) {
            $io->error('Failed to create zip file at ' . $zipPath);
            return Command::FAILURE;
        }

        $files = new \RecursiveIteratorIterator(
            new \RecursiveDirectoryIterator($targetDir, \RecursiveDirectoryIterator::SKIP_DOTS),
            \RecursiveIteratorIterator::LEAVES_ONLY
        );

        foreach ($files as $file) {
            if (!$file->isFile()) {
                continue;
            }
            $filePath = $file->getRealPath();
            // skip the zip file itself
            if ($filePath === $zipPath) {
                continue;
            }
            $relativePath = substr($filePath, strlen($targetDir) + 1);
            $zip->addFile($filePath, $relativePath);
        }

        $zip->close();
        $io->success('Zip archive created at: ' . $zipPath);

        return Command::SUCCESS;
    }
}
